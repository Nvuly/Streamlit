### 필요한 라이브러리 임폴트
import streamlit as st

### 실행 코드 작성

# 텍스트 출력
st.write("어서와.streamlit은 처음이지")

# 이미지 출력
st.image('hello.jpg', caption='어서와~')