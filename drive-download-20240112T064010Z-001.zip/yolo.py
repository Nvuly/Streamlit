import streamlit as st
from PIL import Image
import ultralytics
from ultralytics import YOLO
import os

# ### sidebar 설정
# with st.sidebar:
#     # st.subheader("object detection")

### 제목 설정
st.title("objec detection")


# file upload 기능 구현
file_name = st.file_uploader("Upload a image")

# set image
# image = 'https://github.com/ultralytics/yolov5/raw/master/data/images/zidane.jpg'

# layout 설정 
col1, col2 = st.columns(2)

# 모델 추론 실행
if file_name is not None:
    image = Image.open(file_name)

    # 결과 출력
    with col1:
        with st.expander("sample"):
            st.image(file_name)
    with col2:
        with st.expander("추론 결과"):
            command = 'yolo task=detect mode=predict model=best.pt conf=0.25 source=test5.JPG save=true'
            os.system(command)
            file_path='runs/detect/predict2/test5.JPG'
            st.image(file_path)


# st.subheader("")
# render = render_result(model=model, image=image, result=results[0])
# render.show()
