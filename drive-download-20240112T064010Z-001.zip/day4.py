### 필요한 라이브러리 임폴트
import streamlit as st
import pandas as pd

#@@ sidebar 설치 + selectbox 추가
add_sidebar = st.sidebar.selectbox(
    'Favorite food?',
    ('Apple', 'Banana', 'Pop corn')
)

## selectbox 선택에 따른 메세지 출력
if add_sidebar == 'Apple':
    st.write('YOU CHOOSE APPLE!')
elif add_sidebar == 'Banana':
    st.write('YOU CHOOSE BANANA!')
else:
    st.write('YOU CHOOSE POP CORN!')


## with 구문을 이용한 sidebar 설치 + radio 버튼 추가
with st.sidebar:
    add_radio = st.radio(
        'choose a language',
        ('English', 'Korean', 'Python')
    )
    if add_radio == 'Python':
        st.write('Good Python!')
    elif add_radio == 'English':
        st.write('English!')
    else:
        st.write('You Choose K-Language!')


### layout 생성 --> 수치 정보 추가
col1, col2, col3 = st.columns(3)
with col1:
    st.metric(label='Temperature', value='70F', delta='1.2F')
with col2:
    st.metric(label='Wind', value='2m/s', delta='-8%')
with col3:
    st.metric(label='Humidity', value='86%', delta='4%')

print('\n')

### DataFrame 생성 및 출력

# 제목 생성
st.header("DataFrame 생성하기")

# DataFrame 생성
df = pd.read_csv('iris_dataset.csv')

### button 생성

# "버튼을 생상해서 버튼을 클릭하면" --> if st.button():  
if st.button("DataFrame 생성"):
    st.write(df)

















